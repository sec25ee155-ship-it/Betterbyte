from app import risk_score, risk_label

def test_normal_values_have_lower_flag():
    score = risk_score(25, 120, 75, 36.8, 98, False)
    assert score < 2
    assert risk_label(score)[0] == "Lower screening flag"

def test_multiple_concerning_values_have_high_flag():
    score = risk_score(70, 155, 105, 38.2, 92, True)
    assert score >= 4
    assert risk_label(score)[0] == "High screening flag"

def test_high_systolic_bp_adds_points():
    normal = risk_score(45, 120, 80, 36.8, 97, False)
    elevated = risk_score(45, 145, 80, 36.8, 97, False)
    assert elevated > normal
