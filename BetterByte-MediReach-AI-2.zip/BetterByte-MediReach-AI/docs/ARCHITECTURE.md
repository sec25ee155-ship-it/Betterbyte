# Architecture — MediReach AI

## Current prototype flow

```text
User / Community Health Worker
            |
            v
   Streamlit Web Interface
            |
            v
   Health Inputs (manual)
 age, systolic BP, pulse, temperature, SpO2, symptoms
            |
            v
   Rule-based demo scoring
            |
            v
   Screening flag + general guidance
            |
            v
   User decides whether to contact a qualified professional

Synthetic CSV --> Pandas --> Community dashboard
```

## Components
- `app.py`: Streamlit interface and simple illustrative rules.
- `data/sample_health_data.csv`: synthetic sample records.
- `tests/test_app.py`: basic unit tests.
- `requirements.txt`: Python dependencies.

## Production considerations / future architecture
A real deployment would need user consent, authentication, encryption, data minimisation, audit logs, validated clinical protocols, professional oversight, accessibility and language support, and regulatory/privacy review. Integrations with telemedicine providers or medical devices should be added only after appropriate validation.

## Safety limitation
The scoring logic is a hackathon demonstration and is not a medical device or a clinically validated risk model. It must not be used for diagnosis, triage, or treatment decisions.
