# Test Cases

| ID | Input scenario | Expected behaviour |
|---|---|---|
| TC01 | Adult with normal demo values and no symptoms | Lower screening flag |
| TC02 | Multiple concerning values | High screening flag |
| TC03 | Elevated systolic BP compared with normal BP | Score increases |
| TC04 | Submit the Streamlit form | Result and guidance are displayed |
| TC05 | Open community dashboard | Synthetic sample rows and summary metrics are displayed |

Run unit tests with `pytest`.
