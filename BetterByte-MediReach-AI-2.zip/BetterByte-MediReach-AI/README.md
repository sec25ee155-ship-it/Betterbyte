# MediReach AI — BetterByte

**Hack for Social Cause | Healthcare & Well-being**

MediReach AI is a hackathon prototype exploring preventive screening and remote health awareness for underserved communities.

## Problem
Rural and underserved communities can face barriers to routine screening, timely healthcare advice and ongoing monitoring.

## Prototype
The Streamlit app lets a user enter basic observations (age, systolic blood pressure, heart rate, temperature, SpO₂ and whether symptoms are present). An illustrative rule-based function returns a screening flag and general guidance. A second tab shows synthetic community sample data.

## Features
- Interactive screening form
- Simple rule-based demo scoring
- Low/moderate/high-style screening guidance
- Community dashboard using synthetic data
- Unit tests, architecture notes and MIT license

## Tech stack
Python · Streamlit · Pandas · Pytest

## Run locally

1. Install Python 3.10 or newer.
2. Extract or clone this repository and open a terminal in the project folder.
3. Create a virtual environment:

**Windows**
```bash
python -m venv .venv
.venv\Scripts\activate
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

4. Install dependencies:
```bash
pip install -r requirements.txt
```

5. Launch:
```bash
streamlit run app.py
```

6. Run tests:
```bash
pytest
```

## Deploy on Streamlit Community Cloud
1. Push this folder to a GitHub repository named `MediReach-AI`.
2. Sign in to Streamlit Community Cloud using GitHub.
3. Choose **Create app**, select the repository and branch, and set the main file path to `app.py`.
4. Deploy. Check the logs if dependencies or configuration need attention.

## Repository layout
```text
BetterByte-MediReach-AI/
├── app.py
├── requirements.txt
├── README.md
├── LICENSE
├── .gitignore
├── data/sample_health_data.csv
├── docs/ARCHITECTURE.md
├── docs/TEST_CASES.md
└── tests/test_app.py
```

## UN SDG alignment
- **SDG 3:** Good Health and Well-being
- **SDG 9:** Industry, Innovation and Infrastructure
- **SDG 10:** Reduced Inequalities

## Important safety note
This is an educational hackathon prototype, not a diagnostic or triage tool. The score is illustrative and has not been clinically validated. Do not use it to make medical decisions. Real-world deployment requires clinical validation, informed consent, security/privacy safeguards, and qualified healthcare-professional oversight. In an emergency, contact local emergency services.

## License
MIT — see `LICENSE`.
