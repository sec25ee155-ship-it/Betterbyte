import streamlit as st
import pandas as pd
from pathlib import Path

st.set_page_config(page_title="MediReach AI | BetterByte", page_icon="🩺", layout="wide")
DATA = Path(__file__).parent / "data" / "sample_health_data.csv"

def risk_score(age, systolic_bp, heart_rate, temperature_c, spo2, symptoms):
    """Simple demo rules only; not clinically validated."""
    score = 0
    if age >= 60:
        score += 1
    if systolic_bp >= 140:
        score += 2
    if heart_rate < 50 or heart_rate > 100:
        score += 1
    if temperature_c >= 38.0:
        score += 1
    if spo2 < 95:
        score += 2
    if symptoms:
        score += 1
    return score

def risk_label(score):
    if score >= 4:
        return "High screening flag", "Seek prompt advice from a qualified healthcare professional."
    if score >= 2:
        return "Moderate screening flag", "Consider contacting a healthcare professional for guidance."
    return "Lower screening flag", "Continue routine preventive care and seek help if you feel unwell."

st.title("🩺 MediReach AI")
st.caption("A BetterByte prototype for preventive healthcare access")
st.info("Hackathon prototype only. This tool does not diagnose, predict, or treat disease. Do not use it for emergencies or medical decisions.")

tab_screen, tab_dashboard, tab_about = st.tabs(["Health Screening", "Community Dashboard", "About"])

with tab_screen:
    st.subheader("Enter basic health observations")
    st.write("Use only your own measurements or the clearly labelled simulated examples.")
    with st.form("screening"):
        left, right = st.columns(2)
        with left:
            age = st.number_input("Age (years)", min_value=1, max_value=120, value=25)
            bp = st.number_input("Systolic blood pressure (mmHg)", min_value=70, max_value=250, value=120)
            pulse = st.number_input("Heart rate (beats/min)", min_value=30, max_value=220, value=75)
        with right:
            temp = st.number_input("Temperature (°C)", min_value=34.0, max_value=43.0, value=36.8, step=0.1)
            spo2 = st.number_input("SpO₂ (%)", min_value=70, max_value=100, value=98)
            symptoms = st.checkbox("I have symptoms or a health concern")
        submitted = st.form_submit_button("Show screening guidance", type="primary")

    if submitted:
        score = risk_score(age, bp, pulse, temp, spo2, symptoms)
        label, guidance = risk_label(score)
        st.subheader("Your screening result")
        st.metric("Demo score (not a clinical score)", score)
        if score >= 4:
            st.error(label)
        elif score >= 2:
            st.warning(label)
        else:
            st.success(label)
        st.write(guidance)
        st.caption("This rule-based score is illustrative and has not been clinically validated.")
        if spo2 < 90 or symptoms:
            st.warning("If you have severe breathing difficulty, chest pain, fainting, or another emergency, seek local emergency care immediately.")

with tab_dashboard:
    st.subheader("Simulated community health data")
    if DATA.exists():
        df = pd.read_csv(DATA)
        st.caption("All records below are synthetic demo data, not real patients.")
        a, b, c = st.columns(3)
        a.metric("Sample records", len(df))
        b.metric("Communities represented", df["community"].nunique())
        c.metric("High flags in sample", int((df["risk_category"] == "High").sum()))
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.bar_chart(df["risk_category"].value_counts())
    else:
        st.warning("Sample dataset not found.")

with tab_about:
    st.subheader("Project overview")
    st.write("MediReach AI explores how simple digital screening and referral prompts might support preventive healthcare in underserved communities.")
    st.markdown("""
**Target communities**
- Rural and low-income households
- Older adults and people with limited healthcare access
- Community health workers and primary healthcare centres

**Prototype stack**
- Python, Streamlit and Pandas
- Rule-based demo screening logic
- Synthetic CSV dataset and pytest tests

**Future scope**
- Multilingual and low-bandwidth interface
- Telemedicine and community health-worker referral workflow
- Connected portable diagnostic devices
- Clinical validation, consent, privacy and security controls before any real-world use
""")
    st.write("UN SDG alignment: SDG 3 (Good Health and Well-being), SDG 9 (Industry, Innovation and Infrastructure), SDG 10 (Reduced Inequalities).")
